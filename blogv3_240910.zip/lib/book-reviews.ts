import fs from 'fs'
import path from 'path'
import matter from 'gray-matter'
import { remark } from 'remark'
import html from 'remark-html'

const bookReviewsDirectory = path.join(process.cwd(), 'book-reviews')

export async function getSortedBookReviewsData() {
  const fileNames = fs.readdirSync(bookReviewsDirectory)
  const allBookReviewsData = await Promise.all(fileNames.map(async (fileName) => {
    const id = fileName.replace(/\.md$/, '')
    const fullPath = path.join(bookReviewsDirectory, fileName)
    const fileContents = fs.readFileSync(fullPath, 'utf8')
    const matterResult = matter(fileContents)

    return {
      id,
      ...(matterResult.data as { 
        date: string; 
        title: string; 
        author: string; 
        rating: number;
        coverImage: string;
      })
    }
  }))

  return allBookReviewsData.sort((a, b) => (a.date < b.date ? 1 : -1))
}

export async function getBookReviewData(slug: string) {
  const fullPath = path.join(bookReviewsDirectory, `${slug}.md`)
  const fileContents = fs.readFileSync(fullPath, 'utf8')
  const matterResult = matter(fileContents)
  const processedContent = await remark()
    .use(html)
    .process(matterResult.content)
  const contentHtml = processedContent.toString()

  return {
    slug,
    contentHtml,
    ...(matterResult.data as { 
      date: string; 
      title: string; 
      author: string; 
      rating: number;
      coverImage: string;
      tags: string[];
      reviewer: string;
    })
  }
}