import Link from 'next/link'
import { getSortedPostsData } from '../lib/posts'
import Pagination from '../components/Pagination'

const POSTS_PER_PAGE = 6 // 한 페이지당 표시할 포스트 수

export default async function Home({ searchParams }: { searchParams: { page?: string } }) {
  const allPostsData = await getSortedPostsData()
  const page = parseInt(searchParams.page || '1')
  const totalPosts = allPostsData.length
  const totalPages = Math.ceil(totalPosts / POSTS_PER_PAGE)

  const paginatedPosts = allPostsData.slice(
    (page - 1) * POSTS_PER_PAGE,
    page * POSTS_PER_PAGE
  )

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-center">AI Tech Blog</h1>
      <div className="grid gap-6 md:grid-cols-2">
        {paginatedPosts.map(({ id, date, title, author, tags, category }) => (
          <Link key={id} href={`/posts/${id}`} className="block">
            <article className="bg-white shadow-md rounded-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <div className="p-6">
                <h2 className="text-xl font-semibold mb-2 text-gray-800">{title}</h2>
                {category && (
                  <p className="text-gray-600 mb-2">{category}</p>
                )}
                <p className="text-gray-600 mb-4">{author} • {date}</p>
                {tags && tags.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {tags.map(tag => (
                      <span key={tag} className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </article>
          </Link>
        ))}
      </div>
      <Pagination currentPage={page} totalPages={totalPages} basePath="/posts" />
    </div>
  )
}