'use client';

import { useState, useEffect } from 'react';
import LoginForm from '../../components/LoginForm';
import ContentForm from '../../components/ContentForm';
import BookReviewForm from '../../components/BookReviewForm';

const ADMIN_CREDENTIALS = {
  username: 'admin',
  password: 'password123',
};

export default function AdminPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState('content');

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    setIsLoggedIn(loggedIn);
  }, []);

  const handleLogin = (username: string, password: string) => {
    if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
      localStorage.setItem('isLoggedIn', 'true');
      setIsLoggedIn(true);
    } else {
      alert('Invalid credentials');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    setIsLoggedIn(false);
  };

  if (!isLoggedIn) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <button onClick={handleLogout} className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600">
          Logout
        </button>
      </div>
      <div className="mb-6">
        <button
          onClick={() => setActiveTab('content')}
          className={`mr-4 px-4 py-2 rounded-md ${activeTab === 'content' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
        >
          Content
        </button>
        <button
          onClick={() => setActiveTab('bookReview')}
          className={`px-4 py-2 rounded-md ${activeTab === 'bookReview' ? 'bg-blue-500 text-white' : 'bg-gray-200'}`}
        >
          Book Review
        </button>
      </div>
      {activeTab === 'content' ? <ContentForm /> : <BookReviewForm />}
    </div>
  );
}