import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export async function POST(request: Request) {
  const { title, content, tags, date, category } = await request.json();

  // 날짜와 시간 포맷팅
  const formattedDateTime = new Date(date).toISOString().replace(/T/, ' ').replace(/\..+/, '');
  const formattedDate = formattedDateTime.split(' ')[0];

  const hash = crypto.createHash('md5').update(title).digest('hex').substring(0, 6);
  const fileName = `post_${formattedDate}_${hash}.md`;
  const filePath = path.join(process.cwd(), 'posts', fileName);

  const fileContent = `---
title: "${title}"
date: "${formattedDateTime}"
tags: [${tags.map((tag: string) => `"${tag}"`).join(', ')}]
category: "${category}"
author: "Donghyuk Kim"
---

${content}
`;

  try {
    fs.writeFileSync(filePath, fileContent);
    return NextResponse.json({ message: 'Post created successfully' }, { status: 201 });
  } catch (error) {
    console.error('Error creating post:', error);
    return NextResponse.json({ message: 'Failed to create post' }, { status: 500 });
  }
}