import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export async function POST(request: Request) {
  const { title, author, rating, content, tags, coverImage, date } = await request.json();

  const formattedDateTime = new Date(date).toISOString().replace(/T/, ' ').replace(/\..+/, '');
  const formattedDate = formattedDateTime.split(' ')[0];

  const hash = crypto.createHash('md5').update(title).digest('hex').substring(0, 6);
  const fileName = `book_review_${formattedDate}_${hash}.md`;
  const filePath = path.join(process.cwd(), 'book-reviews', fileName);

  const fileContent = `---
title: "${title}"
author: "${author}"
rating: ${rating}
date: "${formattedDateTime}"
tags: [${tags.map((tag: string) => `"${tag}"`).join(', ')}]
coverImage: "${coverImage}"
---

${content}
`;

  try {
    // 'book-reviews' 디렉토리가 없으면 생성
    const dirPath = path.join(process.cwd(), 'book-reviews');
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }

    fs.writeFileSync(filePath, fileContent);
    return NextResponse.json({ message: 'Book review created successfully' }, { status: 201 });
  } catch (error) {
    console.error('Error creating book review:', error);
    return NextResponse.json({ message: 'Failed to create book review' }, { status: 500 });
  }
}

export async function GET() {
  const dirPath = path.join(process.cwd(), 'book-reviews');
  
  try {
    const files = fs.readdirSync(dirPath);
    const bookReviews = files.map(file => {
      const filePath = path.join(dirPath, file);
      const fileContent = fs.readFileSync(filePath, 'utf-8');
      const [frontmatter, content] = fileContent.split('---').filter(Boolean);
      
      const metadata = frontmatter.split('\n').reduce((acc, line) => {
        const [key, ...value] = line.split(':');
        if (key && value) {
          acc[key.trim()] = value.join(':').trim().replace(/^"(.*)"$/, '$1');
        }
        return acc;
      }, {} as Record<string, string>);

      return {
        id: file.replace('.md', ''),
        ...metadata,
        content: content.trim(),
      };
    });

    return NextResponse.json(bookReviews);
  } catch (error) {
    console.error('Error reading book reviews:', error);
    return NextResponse.json({ message: 'Failed to read book reviews' }, { status: 500 });
  }
}