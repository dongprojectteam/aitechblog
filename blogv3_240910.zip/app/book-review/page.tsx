import Link from 'next/link';
import Image from 'next/image';
import { getSortedBookReviewsData } from '../../lib/book-reviews';
import Pagination from '../../components/Pagination';

const ITEMS_PER_PAGE = 6;

export default async function BookReviewsPage({
  searchParams,
}: {
  searchParams: { page: string };
}) {
  const allBookReviews = await getSortedBookReviewsData();
  const page = parseInt(searchParams.page || '1', 10);
  const totalPages = Math.ceil(allBookReviews.length / ITEMS_PER_PAGE);

  const bookReviews = allBookReviews.slice(
    (page - 1) * ITEMS_PER_PAGE,
    page * ITEMS_PER_PAGE
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Book Reviews</h1>
      <div className="grid gap-8 md:grid-cols-2">
        {bookReviews.map((review) => (
          <article key={review.id} className="bg-white shadow-lg rounded-lg overflow-hidden">
            <div className="relative h-48 bg-gray-200">
              {review.coverImage ? (
                <Image
                  src={review.coverImage}
                  alt={`Cover of ${review.title}`}
                  layout="fill"
                  objectFit="cover"
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                  <svg className="w-16 h-16" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                    <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                  </svg>
                </div>
              )}
            </div>
            <div className="p-6">
              <h2 className="text-xl font-semibold mb-2">
                <Link href={`/book-review/${review.id}`} className="hover:underline">
                  {review.title}
                </Link>
              </h2>
              <p className="text-gray-600 mb-2">by {review.author}</p>
              <div className="flex items-center mb-2">
                <span className="text-yellow-500 mr-1">★</span>
                <span>{review.rating.toFixed(1)}</span>
              </div>
              <p className="text-sm text-gray-500">
                Review date: {new Date(review.date).toLocaleDateString()}
              </p>
            </div>
          </article>
        ))}
      </div>
      <Pagination currentPage={page} totalPages={totalPages} basePath="/book-review"  />
    </div>
  );
}